import pytest
from pages.swag_labs import SwagLabs
from selenium.webdriver.common.by import By

def test_check_login_icon(driver):
    page = SwagLabs(driver)
    page.visit()
    assert page.exist_icon() == True, 'Логотип не найден'

def test_username_field_exists(driver):
    page = SwagLabs(driver)
    page.visit()
    try:
        page.find_element((By.ID, 'user-name'))
        field_exists = True
    except:
        field_exists = False
    assert field_exists, 'Поле имени (username) не найдено'

def test_password_field_exists(driver):
    page = SwagLabs(driver)
    page.visit()
    try:
        page.find_element((By.ID, 'password'))
        field_exists = True
    except:
        field_exists = False
    assert field_exists, 'Поле пароля не найдено'
