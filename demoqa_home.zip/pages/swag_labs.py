from pages.base_page import BasePage
from selenium.common.exceptions import NoSuchElementException

class SwagLabs(BasePage):
    def exist_icon(self):
        try:
            self.find_element(('css selector', 'div.login_logo'))
        except NoSuchElementException:
            return False
        return True
